React Client-Side-Rendering App:

A simple app with Client side rendering.

```sh
### install the dependencies
npm i
### start the application
npm start
```