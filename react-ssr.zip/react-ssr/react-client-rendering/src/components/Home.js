import React from 'react';

const Home = () => {
    return (<div>
        <h2>This is the Home Page</h2>
        <h5>Welcome</h5>
    </div>)
}

export default Home;