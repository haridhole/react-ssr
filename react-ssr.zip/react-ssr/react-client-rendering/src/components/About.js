import React from 'react';

const About = () => {
    return (<div>
        <h2>This is the About Page</h2>
        <h5>Sample to convert Client APP to SSR</h5>
    </div>)
}

export default About;