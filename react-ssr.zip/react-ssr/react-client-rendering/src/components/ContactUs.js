import React from 'react';

const ContactUs = () => {
    return (<div>
        <h2>This is the Contact Page Page</h2>
        <h5>Linkedin - <a target="_blank" rel="noopener noreferrer" href="https://www.linkedin.com/in/vilvaathiban/"> Click here</a></h5>
    </div>)
}

export default ContactUs;