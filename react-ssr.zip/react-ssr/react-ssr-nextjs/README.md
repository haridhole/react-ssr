React Server-Side-Rendering Using NextJS App:

A simple app with Client side rendering.

```sh
### install the dependencies
npm i
### start the application
npm run build
npm run start
```